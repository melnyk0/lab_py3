import module1  # Використовуйте module1 або module2 залежно від пакету
import os

def read_config(config_file):
    """Читає конфігураційний файл і повертає налаштування."""
    config = {}
    try:
        with open(config_file, 'r', encoding='utf-8') as file:
            for line in file:
                key, value = line.strip().split('=')
                config[key] = value
    except Exception as e:
        print(f"Помилка читання конфігураційного файлу: {e}")
    return config

def analyze_text(text):
    """Аналізує текст і повертає кількість символів, слів і речень."""
    char_count = len(text)
    word_count = len(text.split())
    sentence_count = text.count('.') + text.count('!') + text.count('?')
    return char_count, word_count, sentence_count

def translate_text(text, src, dest):
    """Перекладає текст за допомогою функції TransLate з модуля."""
    try:
        translated_text = module1.TransLate(text, src, dest)
        return translated_text
    except Exception as e:
        print(f"Помилка перекладу: {e}")
        return None

def save_to_file(filename, content):
    """Зберігає текст у файл."""
    try:
        with open(filename, 'w', encoding='utf-8') as file:
            file.write(content)
        print(f"Переклад збережено у файл: {filename}")
    except Exception as e:
        print(f"Помилка збереження у файл: {e}")

def process_file(config_file):
    """Основна функція, яка обробляє текстовий файл і робить переклад."""
    config = read_config(config_file)
    
    text_file = config.get('text_file', 'input.txt')
    target_language = config.get('target_language', 'en')
    output = config.get('output', 'screen')
    max_chars = int(config.get('max_chars', 1000))
    max_words = int(config.get('max_words', 200))
    max_sentences = int(config.get('max_sentences', 10))
    
    if not os.path.exists(text_file):
        print(f"Файл {text_file} не знайдено.")
        return

    try:
        # Отримуємо розмір файлу
        file_size = os.path.getsize(text_file)
        
        with open(text_file, 'r', encoding='utf-8') as file:
            text = ''
            char_count, word_count, sentence_count = 0, 0, 0
            
            for line in file:
                text += line
                char_count, word_count, sentence_count = analyze_text(text)
                
                # Перевірка, чи досягнуто одну з умов зупинки
                if char_count > max_chars or word_count > max_words or sentence_count > max_sentences:
                    break
        
        print(f"Назва файлу: {text_file}")
        print(f"Розмір файлу: {file_size} байт")
        print(f"Кількість символів: {char_count}")
        print(f"Кількість слів: {word_count}")
        print(f"Кількість речень: {sentence_count}")
        
        # Визначаємо мову тексту
        detected_language = module1.LangDetect(text, 'lang')
        print(f"Мова тексту: {detected_language}")
        
        # Перекладаємо текст
        translated_text = translate_text(text, 'auto', target_language)
        if translated_text is None:
            return

        # Виводимо або зберігаємо результат
        if output == 'screen':
            print(f"Мова перекладу: {target_language}")
            print(f"Переклад:\n{translated_text}")
        elif output == 'file':
            output_filename = f"{os.path.splitext(text_file)[0]}_{target_language}.txt"
            save_to_file(output_filename, translated_text)
            print("Ok")
        
    except Exception as e:
        print(f"Помилка обробки файлу: {e}")

if __name__ == '__main__':
    process_file('config.txt')
