from googletrans import Translator
import re
from lab_2_languages import LANGUAGES

def TransLate(text, target_lang):
    translator = Translator()
    try:
        # Переклад на мову, вказану користувачем
        translated = translator.translate(text, dest=target_lang)
        return translated.text
    except Exception as e:
        return f"Помилка при перекладі: {e}"

def LangDetect(txt):
    translator = Translator()
    try:
        detected = translator.detect(txt)
        return detected.lang, detected.confidence
    except Exception as e:
        return f"Помилка при визначенні мови: {e}", None

def is_ukrainian(text):
    # перевіряє, чи містить текст лише українські літери
    return bool(re.fullmatch(r'[А-Яа-яІіЇїЄєҐґ\s]+', text))


if __name__ == "__main__":
    txt = input("Введіть текст українською мовою: ")

    if is_ukrainian(txt):
        print(f"Ви ввели текст: {txt}")
        detected_lang, confidence = LangDetect(txt)
        print(f"Мова тексту: {detected_lang}, достовірність: {confidence}")

        # Запит на введення мови перекладу
        target_lang_input = input("Введіть мову, на яку потрібно перекласти: ").strip().lower()
        
        # Перевірка, чи введена користувачем мова є допустимою
        target_lang = LANGUAGES.get(target_lang_input, target_lang_input)
        if target_lang in LANGUAGES.values():
            # Переклад на вказану мову
            translated_text = TransLate(txt, target_lang)
            print(f"Перекладений текст на {target_lang_input}: {translated_text}")
        else:
            print("Невідома мова. Будь ласка, введіть коректну назву.")
    else:
        print("Будь ласка, введіть текст лише українською мовою.")
