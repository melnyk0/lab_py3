def is_prime(n):
    # перевіряє, чи є число n простим
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def find_primes(a, b):
    start = min(a, b)
    end = max(a, b)

    # знаходимо прості числа в діапазоні
    primes = []
    for i in range(start, end + 1):
        if is_prime(i):
            primes.append(i)
    return primes

a = int(input("Введіть перше число (a): "))
b = int(input("Введіть друге число (b): "))

# знаходимо та виводимо прості числа
primes = find_primes(a, b)
print(f"Прості числа між {a} і {b}: {primes}")
