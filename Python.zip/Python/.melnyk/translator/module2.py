from deep_translator import GoogleTranslator
from langdetect import detect, detect_langs
from deep_translator.constants import GOOGLE_LANGUAGES_TO_CODES, GOOGLE_CODES_TO_LANGUAGES

def TransLate(text: str, scr: str = 'auto', dest: str = 'en') -> str:
    """
    Функція повертає текст, перекладений на задану мову, або повідомлення про помилку.
    :param text: Текст, який необхідно перекласти
    :param scr: Код мови або 'auto' для автоматичного визначення мови
    :param dest: Код мови, на яку треба перекласти текст
    :return: Перекладений текст або повідомлення про помилку
    """
    try:
        if scr == 'auto':
            scr = detect(text)
        translator = GoogleTranslator(source=scr, target=dest)
        return translator.translate(text)
    except Exception as e:
        return f"Помилка: {str(e)}"

def LangDetect(text: str, set: str = 'all') -> str:
    """
    Функція визначає мову та коефіцієнт довіри для заданого тексту.
    :param text: Текст для якого потрібно визначити мову
    :param set: 'lang' - повертає мову, 'confidence' - повертає коефіцієнт довіри, 'all' - обидва
    :return: Мова та/або коефіцієнт довіри або повідомлення про помилку
    """
    try:
        lang_confidence = detect_langs(text)
        lang = lang_confidence[0].lang
        confidence = lang_confidence[0].prob
        if set == 'lang':
            return lang
        elif set == 'confidence':
            return str(confidence)
        else:
            return f"Мова: {lang}, Коефіцієнт довіри: {confidence}"
    except Exception as e:
        return f"Помилка: {str(e)}"

def CodeLang(lang: str) -> str:
    """
    Функція повертає код мови або назву мови залежно від введеного параметра.
    :param lang: Назва або код мови
    :return: Код або назва мови або повідомлення про помилку
    """
    try:
        if lang in GOOGLE_LANGUAGES_TO_CODES:
            return GOOGLE_LANGUAGES_TO_CODES[lang]
        elif lang in GOOGLE_CODES_TO_LANGUAGES:
            return GOOGLE_CODES_TO_LANGUAGES[lang]
        else:
            return "Помилка: Невідома мова або код."
    except Exception as e:
        return f"Помилка: {str(e)}"

def LanguageList(out: str = 'screen', text: str = '') -> str:
    """
    Функція виводить список підтримуваних мов та їх кодів, а також перекладений текст (якщо наданий).
    :param out: 'screen' - вивести на екран, 'file' - зберегти у файл
    :param text: Текст для перекладу на кожну мову (опційно)
    :return: 'Ok' або повідомлення про помилку
    """
    try:
        languages = GOOGLE_LANGUAGES_TO_CODES
        table = f"N | Language      | ISO-639 code | Text\n" + "-"*50 + "\n"
        translated_texts = []

        for i, (language, code) in enumerate(languages.items(), 1):
            translated_text = ''
            if text:
                translated_text = TransLate(text, 'auto', code)
            translated_texts.append(f"{i:<2} | {language:<12} | {code:<12} | {translated_text}")
        
        if out == 'screen':
            print(table + "\n".join(translated_texts))
        elif out == 'file':
            with open('languages_deep.txt', 'w', encoding='utf-8') as f:
                f.write(table + "\n".join(translated_texts))

        return 'Ok'
    except Exception as e:
        return f"Помилка: {str(e)}"
