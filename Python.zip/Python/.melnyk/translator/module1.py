from googletrans import Translator
from lab_2_languages import LANGUAGES

translator = Translator()

def TransLate(text: str, scr: str = 'auto', dest: str = 'en') -> str:
    """
    Функція повертає текст, перекладений на задану мову, або повідомлення про помилку.
    :param text: Текст, який необхідно перекласти
    :param scr: Код мови або 'auto' для автоматичного визначення мови
    :param dest: Код мови, на яку треба перекласти текст
    :return: Перекладений текст або повідомлення про помилку
    """
    try:
        translation = translator.translate(text, src=scr, dest=dest)
        return translation.text
    except Exception as e:
        return f"Помилка: {str(e)}"

def LangDetect(text: str, set: str = 'all') -> str:
    """
    Функція визначає мову та коефіцієнт довіри для заданого тексту.
    :param text: Текст для якого потрібно визначити мову
    :param set: 'lang' - повертає мову, 'confidence' - повертає коефіцієнт довіри, 'all' - обидва
    :return: Мова та/або коефіцієнт довіри або повідомлення про помилку
    """
    try:
        detection = translator.detect(text)
        if set == 'lang':
            return detection.lang
        elif set == 'confidence':
            return str(detection.confidence)
        else:
            return f"Мова: {detection.lang}, Коефіцієнт довіри: {detection.confidence}"
    except Exception as e:
        return f"Помилка: {str(e)}"

def CodeLang(lang: str) -> str:
    """
    Функція повертає код мови або назву мови залежно від введеного параметра.
    :param lang: Назва або код мови
    :return: Код або назва мови або повідомлення про помилку
    """
    try:
        if lang in LANGUAGES:
            return LANGUAGES[lang]
        elif lang in LANGUAGES.values():
            for key, value in LANGUAGES.items():
                if value == lang:
                    return key
        else:
            return "Помилка: Невідома мова або код."
    except Exception as e:
        return f"Помилка: {str(e)}"

def LanguageList(out: str = 'screen', text: str = '') -> str:
    """
    Функція виводить список підтримуваних мов та їх кодів, а також перекладений текст (якщо наданий).
    :param out: 'screen' - вивести на екран, 'file' - зберегти у файл
    :param text: Текст для перекладу на кожну мову (опційно)
    :return: 'Ok' або повідомлення про помилку
    """
    try:
        languages = LANGUAGES
        table = f"N | Language      | ISO-639 code | Text\n" + "-"*50 + "\n"
        translated_texts = []

        for i, (code, language) in enumerate(languages.items(), 1):
            translated_text = ''
            if text:
                translated_text = TransLate(text, 'auto', code)
            translated_texts.append(f"{i:<2} | {language:<12} | {code:<12} | {translated_text}")
        
        if out == 'screen':
            print(table + "\n".join(translated_texts))
        elif out == 'file':
            with open('languages.txt', 'w', encoding='utf-8') as f:
                f.write(table + "\n".join(translated_texts))

        return 'Ok'
    except Exception as e:
        return f"Помилка: {str(e)}"
