NAME = "Text translation"
AUTHOR = "Мельник Олександр, ІПЗ-22011бск"
