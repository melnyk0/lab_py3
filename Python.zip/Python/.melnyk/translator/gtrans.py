import module1

def main():
    text_to_translate = "Добрий день"
    translated_text = module1.TransLate(text_to_translate, 'auto', 'en')
    print(f"Переклад: {translated_text}")

    lang_detect = module1.LangDetect(text_to_translate, 'all')
    print(f"Визначена мова та коефіцієнт довіри: {lang_detect}")

    lang_code = module1.CodeLang('uk')
    print(f"Назва мови за кодом 'uk': {lang_code}")

    print("Виведення списку мов та їх кодів:")
    module1.LanguageList(out='screen', text="Привіт")

if __name__ == '__main__':
    main()
